package calculadora;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class UsaCalculadora {
	public static void main(String[] args) {
		Calculadora calc = new Calculadora();
		Scanner scan = new Scanner(System.in);
		String opc = "S";
		int operacao = 0;
			
		
		while(opc.equals("s") || opc.equals("S")) {
			
			
			int numero1 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o primeiro número: "));
			calc.setN1(numero1);

			int numero2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o segundo número: "));
			calc.setN2(numero2);
			
			operacao = 0;
			while(operacao == 0) {
				operacao = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o número da operação que deseja fazer:\n1 - ADIÇÃO\n2 - SUBTRAÇÃO\n3 - MULTIPLICAÇÃO\n4 - DIVISÃO"));
				
				JOptionPane.showMessageDialog(null, "Número 1: " + calc.getN1() + "\nNúmero 2: " + calc.getN2());
				
				switch(operacao) {
				case 1: 
					JOptionPane.showMessageDialog(null, "Adição: " + calc.adicao());
					break;
				case 2:
					JOptionPane.showMessageDialog(null, "Subtração: " + calc.subtracao());
					break;
				case 3:
					JOptionPane.showMessageDialog(null, "Multiplicação: " + calc.multiplicacao());
					break;
				case 4:
					if(calc.getN1() == 0 && calc.getN2()== 0) {
						JOptionPane.showMessageDialog(null, "FORMATO DE DIVISÃO INVÁLIDA!");
						operacao = 0;
					}else {
						JOptionPane.showMessageDialog(null, "Divisão: "+calc.divisao());
					}
					break;
				default:
					JOptionPane.showMessageDialog(null, "Número inválido! Digite novamente!");
					operacao = 0;
				}

			}
			
			opc = JOptionPane.showInputDialog(null, "Deseja fazer outra operação?\nSe sim digite S");
			
		}
	}
}
