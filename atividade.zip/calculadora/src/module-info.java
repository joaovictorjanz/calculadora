/**
 * 
 */
/**
 * @author Usuario
 *
 */
module calculadora {
	requires java.desktop;
}